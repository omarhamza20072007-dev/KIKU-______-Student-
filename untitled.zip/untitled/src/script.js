
"use strict";

/*
 KiKu - Frontend demonstration
 التخزين المحلي للتجربة فقط وليس قاعدة بيانات آمنة.
*/

const $ = id => document.getElementById(id);

const DB_KEY = "kiku_demo_database_v1";

const defaultDB = {
  users: [
    {
      id: "admin",
      username: "eng",
      password: "eng",
      name: "إدارة KiKu",
      role: "admin",
      active: true
    }
  ],
  sections: [
    {
      id: "schedule",
      title: "الجدول الدراسي",
      description: "جدول المحاضرات والمعامل",
      details: "لم يتم إعلان الجدول الدراسي حتى الآن.",
      type: "text",
      published: true
    },
    {
      id: "subjects",
      title: "المواد المسجلة",
      description: "المواد الدراسية الخاصة بك",
      details: "لم تتم إضافة المواد بعد.",
      type: "text",
      published: true
    },
    {
      id: "results",
      title: "نتائج المقررات",
      description: "النتائج النهائية للمقررات",
      details: "لم يتم إعلان النتائج حتى الآن.",
      type: "text",
      published: true
    },
    {
      id: "midterm",
      title: "نتيجة الميدتيرم",
      description: "درجات الميدتيرم لجميع المواد",
      details: "لم يتم إعلان نتائج الميدتيرم حتى الآن.",
      type: "text",
      published: true
    },
    {
      id: "payments",
      title: "الدفع الإلكتروني",
      description: "متابعة الرسوم والمدفوعات",
      details: "لا توجد بيانات مدفوعات معلنة.",
      type: "text",
      published: true
    },
    {
      id: "warnings",
      title: "إنذار الفصل",
      description: "متابعة الإنذارات الأكاديمية",
      details: "لا توجد إنذارات أكاديمية مسجلة على حسابك حاليًا.",
      type: "text",
      published: true
    }
  ]
};

let db = loadDB();
let currentUser = null;
let currentSection = "home";
let editingSectionId = null;

function loadDB() {
  try {
    const saved = localStorage.getItem(DB_KEY);
    if (!saved) return structuredClone(defaultDB);

    const parsed = JSON.parse(saved);
    if (!Array.isArray(parsed.users) ||
        !Array.isArray(parsed.sections)) {
      throw new Error("Invalid database");
    }
    return parsed;
  } catch (error) {
    console.error("Database loading error:", error);
    return structuredClone(defaultDB);
  }
}

function saveDB() {
  localStorage.setItem(DB_KEY, JSON.stringify(db));
}

function makeId() {
  return "kiku_" + Date.now() + "_" +
    Math.random().toString(36).slice(2, 8);
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

// تسجيل الدخول
$("loginForm").addEventListener("submit", event => {
  event.preventDefault();

  const username = $("username").value.trim();
  const password = $("password").value;

  const user = db.users.find(item =>
    item.username === username &&
    item.password === password &&
    item.active !== false
  );

  if (!user) {
    $("loginMessage").textContent =
      "بيانات الدخول غير صحيحة أو الحساب غير مفعل.";
    return;
  }

  currentUser = user;
  $("loginMessage").textContent = "";

  $("loginPage").classList.add("hidden");
  $("app").classList.remove("hidden");

  $("userLabel").textContent =
    user.name + (user.role === "admin" ? " - الإدارة" : "");

  currentSection = "home";
  renderApp();
});

$("logoutBtn").addEventListener("click", () => {
  currentUser = null;
  $("app").classList.add("hidden");
  $("loginPage").classList.remove("hidden");
  $("loginForm").reset();
});

// القائمة
function getMenu() {
  if (currentUser.role === "admin") {
    return [
      ["home", "الرئيسية"],
      ["students", "إدارة الطلاب"],
      ["sections", "إدارة الخانات"],
      ["schedule", "الجدول الدراسي"],
      ["results", "نتائج المقررات"],
      ["midterm", "نتائج الميدتيرم"],
      ["subjects", "المواد المسجلة"],
      ["payments", "الدفع الإلكتروني"],
      ["warnings", "إنذارات الفصل"]
    ];
  }

  return [
    ["home", "الرئيسية"],
    ...db.sections
      .filter(section => section.published)
      .map(section => [section.id, section.title])
  ];
}

function renderApp() {
  const menu = getMenu();

  $("navigation").innerHTML = "";

  menu.forEach(([id, title]) => {
    const button = document.createElement("button");
    button.textContent = title;
    button.className =
      id === currentSection ? "active" : "";

    button.addEventListener("click", () => {
      currentSection = id;
      renderApp();
    });

    $("navigation").appendChild(button);
  });

  renderContent();
}

// المحتوى الرئيسي
function renderContent() {
  const main = $("mainContent");

  if (currentSection === "home") {
    main.innerHTML = `
      <div class="welcome-card">
        <h1>مرحباً بك في KiKu</h1>
        <p>
          بوابتك الأكاديمية لطلاب هندسة الذكاء الاصطناعي.
          تابع بياناتك الدراسية وجميع خدماتك التعليمية
          من مكان واحد.
        </p>
      </div>

      <div class="grid">
        <div class="card">
          <h3>الجامعة</h3>
          <p>KiKu</p>
        </div>
        <div class="card">
          <h3>التخصص</h3>
          <p>هندسة الذكاء الاصطناعي</p>
        </div>
        <div class="card">
          <h3>اسم الحساب</h3>
          <p>${escapeHTML(currentUser.name)}</p>
        </div>
        <div class="card">
          <h3>نوع الحساب</h3>
          <p>${currentUser.role === "admin" ? "الإدارة" : "طالب"}</p>
        </div>
      </div>

      <div class="panel" style="margin-top:22px">
        <h3>مرحباً بك في مستقبلك الرقمي</h3>
        <p class="detail-text">
          من خلال بوابة KiKu يمكنك متابعة جدولك الدراسي،
          ونتائجك، والمواد المسجلة، والإعلانات الجامعية.
          نسعى لتوفير تجربة تعليمية سهلة ومنظمة وآمنة.
        </p>
      </div>
    `;
    return;
  }

  if (currentUser.role === "admin") {
    if (currentSection === "students") {
      renderStudents();
      return;
    }

    if (currentSection === "sections") {
      renderSectionManager();
      return;
    }
  }

  const section = db.sections.find(item =>
    item.id === currentSection &&
    item.published
  );

  if (!section) {
    main.innerHTML = `<div class="empty">هذه الخانة غير متاحة.</div>`;
    return;
  }

  renderStudentSection(section);
}

// إدارة الطلاب
function renderStudents() {
  const students = db.users.filter(user => user.role === "student");

  $("mainContent").innerHTML = `
    <div class="section-title">
      <h1>إدارة الطلاب</h1>
      <p>إضافة حسابات الطلاب وإدارة بياناتهم</p>
    </div>

    <div class="panel">
      <h3>إضافة طالب جديد</h3>

      <form id="studentForm">
        <div class="form-grid">
          <div>
            <label>اسم الطالب</label>
            <input name="name" required>
          </div>

          <div>
            <label>رقم الطالب</label>
            <input name="studentId" required>
          </div>

          <div>
            <label>اسم المستخدم</label>
            <input name="username" required>
          </div>

          <div>
            <label>كلمة المرور المؤقتة</label>
            <input name="password" required>
          </div>
        </div>

        <button class="action-btn">إضافة الطالب</button>
      </form>
    </div>

    <div class="section-title"><h2>قائمة الطلاب (${students.length})</h2></div>

    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>الاسم</th>
            <th>رقم الطالب</th>
            <th>اسم المستخدم</th>
            <th>الحالة</th>
            <th>الإجراءات</th>
          </tr>
        </thead>
        <tbody>
          ${students.map(student => `
            <tr>
              <td>${escapeHTML(student.name)}</td>
              <td>${escapeHTML(student.studentId)}</td>
              <td>${escapeHTML(student.username)}</td>
              <td>${student.active === false ? "متوقف" : "نشط"}</td>
              <td>
                <button class="edit-btn"
                  data-toggle="${escapeHTML(student.id)}">
                  ${student.active === false ? "تفعيل" : "إيقاف"}
                </button>
                <button class="delete-btn"
                  data-delete-student="${escapeHTML(student.id)}">
                  حذف
                </button>
              </td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `;

  $("studentForm").addEventListener("submit", event => {
    event.preventDefault();

    const form = new FormData(event.currentTarget);
    const name = form.get("name").trim();
    const studentId = form.get("studentId").trim();
    const username = form.get("username").trim();
    const password = form.get("password");

    if (db.users.some(user =>
      user.username.toLowerCase() === username.toLowerCase() ||
      user.studentId === studentId
    )) {
      alert("اسم المستخدم أو رقم الطالب مستخدم بالفعل.");
      return;
    }

    db.users.push({
      id: makeId(),
      name,
      studentId,
      username,
      password,
      role: "student",
      active: true
    });

    saveDB();
    alert("تمت إضافة الطالب بنجاح.");
    renderApp();
  });

  $("mainContent").querySelectorAll("[data-delete-student]")
    .forEach(button => {
      button.addEventListener("click", () => {
        if (!confirm("هل تريد حذف هذا الطالب؟")) return;

        db.users = db.users.filter(user =>
          user.id !== button.dataset.deleteStudent
        );

        saveDB();
        renderApp();
      });
    });

  $("mainContent").querySelectorAll("[data-toggle]")
    .forEach(button => {
      button.addEventListener("click", () => {
        const student = db.users.find(user =>
          user.id === button.dataset.toggle
        );

        if (!student) return;

        student.active = student.active === false;
        saveDB();
        renderApp();
      });
    });
}

// إدارة الخانات الديناميكية
function renderSectionManager() {
  $("mainContent").innerHTML = `
    <div class="section-title">
      <h1>إدارة الخانات</h1>
      <p>أنشئ أي قسم جديد وسيظهر للطلاب بعد نشره</p>
    </div>

    <div class="panel">
      <h3 id="editorTitle">إنشاء خانة جديدة</h3>

      <form id="sectionForm">
        <div class="form-grid">
          <div>
            <label>اسم الخانة</label>
            <input id="sectionTitle" required
              placeholder="مثلاً: إعلان مهم">
          </div>

          <div>
            <label>نوع المحتوى</label>
            <select id="sectionType">
              <option value="text">نص وتفاصيل</option>
              <option value="table">جدول نصي</option>
              <option value="link">رابط</option>
            </select>
          </div>

          <div class="full">
            <label>وصف الخانة</label>
            <input id="sectionDescription"
              placeholder="وصف مختصر للخانة">
          </div>

          <div class="full">
            <label>تفاصيل الخانة</label>
            <textarea id="sectionDetails" required
              placeholder="اكتب جميع التفاصيل التي تريد عرضها للطلاب"></textarea>
          </div>

          <div>
            <label>حالة الخانة</label>
            <select id="sectionPublished">
              <option value="true">نشر للطلاب</option>
              <option value="false">حفظ بدون نشر</option>
            </select>
          </div>
        </div>

        <button class="action-btn" type="submit">حفظ الخانة</button>
        <button class="edit-btn" type="button" id="cancelEdit">
          إلغاء التعديل
        </button>
      </form>
    </div>

    <div class="section-title">
      <h2>الخانات الموجودة</h2>
    </div>

    <div id="sectionsList" class="grid"></div>
  `;

  $("sectionForm").addEventListener("submit", event => {
    event.preventDefault();

    const title = $("sectionTitle").value.trim();
    const description = $("sectionDescription").value.trim();
    const details = $("sectionDetails").value.trim();
    const type = $("sectionType").value;
    const published = $("sectionPublished").value === "true";

    if (!title || !details) {
      alert("أكمل اسم الخانة والتفاصيل.");
      return;
    }

    if (editingSectionId) {
      const section = db.sections.find(item =>
        item.id === editingSectionId
      );

      if (!section) return;

      section.title = title;
      section.description = description;
      section.details = details;
      section.type = type;
      section.published = published;
    } else {
      db.sections.push({
        id: makeId(),
        title,
        description,
        details,
        type,
        published
      });
    }

    saveDB();
    editingSectionId = null;
    alert("تم حفظ الخانة بنجاح.");
    renderApp();
  });

  $("cancelEdit").addEventListener("click", () => {
    editingSectionId = null;
    renderApp();
  });

  renderSectionsList();
}

function renderSectionsList() {
  const list = $("sectionsList");

  if (!list) return;

  list.innerHTML = "";

  db.sections.forEach(section => {
    const card = document.createElement("div");
    card.className = "card";

    const title = document.createElement("h3");
    title.textContent = section.title;

    const description = document.createElement("p");
    description.textContent = section.description;

    const status = document.createElement("span");
    status.className = "badge";
    status.textContent = section.published ? "منشورة" : "مسودة";

    const edit = document.createElement("button");
    edit.className = "edit-btn";
    edit.textContent = "تعديل";

    edit.addEventListener("click", () => {
      editingSectionId = section.id;
      $("sectionTitle").value = section.title;
      $("sectionDescription").value = section.description;
      $("sectionDetails").value = section.details;
      $("sectionType").value = section.type;
      $("sectionPublished").value = String(section.published);
      $("editorTitle").textContent = "تعديل الخانة";
      window.scrollTo({ top: 0, behavior: "smooth" });
    });

    const remove = document.createElement("button");
    remove.className = "delete-btn";
    remove.textContent = "حذف";

    remove.addEventListener("click", () => {
      if (!confirm("هل تريد حذف الخانة نهائياً؟")) return;

      db.sections = db.sections.filter(item =>
        item.id !== section.id
      );

      saveDB();
      renderApp();
    });

    card.append(title, description, status, edit, remove);
    list.appendChild(card);
  });
}

// عرض الخانة للطالب
function renderStudentSection(section) {
  const details = document.createElement("div");
  details.className = "panel";

  const heading = document.createElement("div");
  heading.className = "section-title";

  const title = document.createElement("h1");
  title.textContent = section.title;

  const description = document.createElement("p");
  description.textContent = section.description;

  heading.append(title, description);

  const content = document.createElement("div");
  content.className = "detail-text";
  content.textContent = section.details;

  details.append(heading, content);

  $("mainContent").replaceChildren(details);
}

// بداية التشغيل
saveDB();
